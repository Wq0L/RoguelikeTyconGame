# ERIGONE — bitki temalı Steam kapsülleri

Kullanıcının seçtiği renkli bitki çekme teması korunarak gezegenin kırıkları aynı yüzey ve gölge diliyle birleştirildi. Yataylarda Eri bitkiyi çeker; dikeyde önceki istek doğrultusunda mutlu biçimde logoda oturur. Kaynaklar kullanıcı referansı ve bu konuşmanın üretimleridir; yeni üçüncü taraf içerik veya font indirilmedi.

PNG dizini Steam yükleme ölçülerini içerir: küçük 462×174, başlık 920×430, ana 1232×706, dikey 748×896. source dizininde büyük üretim kaynakları, design.json içinde yerleşik image_gen istemleri bulunur. Tam PNG boyutları export.ps1 ile doğrulanır. Steam'e yüklenmedi, Unity'ye eklenmedi.
